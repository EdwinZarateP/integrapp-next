@echo off
chcp 65001 >nul
title Instalador Huellas IntegrApp

REM ── Auto-elevacion a administrador ──────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Este instalador necesita permisos de administrador.
    echo  Se abrira de nuevo pidiendo el permiso: presiona "Si".
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================================
echo   INSTALADOR HUELLAS INTEGRAPP  (todo en uno)
echo ============================================================
echo  Este proceso instala el programa, el acceso directo y el
echo  soporte completo del lector de huellas. Al final el equipo
echo  se reiniciara solo (es normal, lo pide el instalador).
echo ============================================================
echo.
echo  1/4  Copiando el programa a C:\HuellasIntegrapp ...
robocopy "%~dp0Aplicacion" "C:\HuellasIntegrapp" /E /NFL /NDL /NJH /NJS >nul

echo  2/4  Desbloqueando archivos (quita el aviso de Proteccion de Windows) ...
powershell -NoProfile -Command "Get-ChildItem -Recurse 'C:\HuellasIntegrapp' | Unblock-File"

echo  3/4  Creando el acceso directo "Huellas IntegrApp" en el escritorio ...
powershell -NoProfile -Command "$e=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('CommonDesktopDirectory')+'\Huellas IntegrApp.lnk'); $e.TargetPath='C:\HuellasIntegrapp\HuellasIntegrapp.exe'; $e.WorkingDirectory='C:\HuellasIntegrapp'; $e.Save()"

echo  4/4  Instalando el soporte del lector (DigitalPersona: runtime + driver) ...
echo       (puede tardar uno o dos minutos sin mostrar nada)
msiexec /i "%~dp0Runtime\DigitalPersona One Touch RTE 1.6.1.msi" /qn REBOOT=ReallySuppress
set RC=%errorlevel%

echo.
if "%RC%"=="0" (
    echo  INSTALACION COMPLETADA.
) else (
    echo  Soporte del lector finalizo con codigo %RC% ^(3010 = normal, requiere reinicio^).
)
echo.
echo  PROXIMO PASO despues del reinicio: conecta el lector de huellas
echo  al puerto USB y abre "Huellas IntegrApp" desde el escritorio.
echo.
echo  El equipo se REINICIARA EN 25 SEGUNDOS para completar la instalacion.
echo  (cierra esta ventana ahora si prefieres reiniciar mas tarde)
shutdown /r /t 25 /c "Reinicio para completar la instalacion de Huellas IntegrApp"
echo.
pause
